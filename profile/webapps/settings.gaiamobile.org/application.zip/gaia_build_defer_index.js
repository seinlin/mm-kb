;'use strict';(function(window){var gL10nData={};var gTextProp='textContent';var gLanguage='';var gMacros={};var gReadyState='loading';var gAsyncResourceLoading=true;var gDEBUG=1;function consoleLog(message){if(gDEBUG>=2){console.log('[l10n] '+message);}};function consoleWarn(message){if(gDEBUG){console.warn('[l10n] '+message);}};function getL10nResourceLinks(){return document.querySelectorAll('link[type="application/l10n"]');}
function getL10nDictionary(){var script=document.querySelector('script[type="application/l10n"]');return script?JSON.parse(script.innerHTML):null;}
function getTranslatableChildren(element){return element?element.querySelectorAll('*[data-l10n-id]'):[];}
function getL10nAttributes(element){if(!element)
return{};var l10nId=element.getAttribute('data-l10n-id');var l10nArgs=element.getAttribute('data-l10n-args');var args={};if(l10nArgs){try{args=JSON.parse(l10nArgs);}catch(e){consoleWarn('could not parse arguments for #'+l10nId);}}
return{id:l10nId,args:args};}
function fireL10nReadyEvent(){var evtObject=document.createEvent('Event');evtObject.initEvent('localized',false,false);evtObject.language=gLanguage;window.dispatchEvent(evtObject);}
function parseResource(href,lang,successCallback,failureCallback){var baseURL=href.replace(/\/[^\/]*$/,'/');function evalString(text){if(text.lastIndexOf('\\')<0)
return text;return text.replace(/\\\\/g,'\\').replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\\t/g,'\t').replace(/\\b/g,'\b').replace(/\\f/g,'\f').replace(/\\{/g,'{').replace(/\\}/g,'}').replace(/\\"/g,'"').replace(/\\'/g,"'");}
function parseProperties(text){var dictionary=[];var reBlank=/^\s*|\s*$/;var reComment=/^\s*#|^\s*$/;var reSection=/^\s*\[(.*)\]\s*$/;var reImport=/^\s*@import\s+url\((.*)\)\s*$/i;var reSplit=/^([^=\s]*)\s*=\s*(.+)$/;function parseRawLines(rawText,extendedSyntax){var entries=rawText.replace(reBlank,'').split(/[\r\n]+/);var currentLang='*';var genericLang=lang.replace(/-[a-z]+$/i,'');var skipLang=false;var match='';for(var i=0;i<entries.length;i++){var line=entries[i];if(reComment.test(line))
continue;if(extendedSyntax){if(reSection.test(line)){match=reSection.exec(line);currentLang=match[1];skipLang=(currentLang!=='*')&&(currentLang!==lang)&&(currentLang!==genericLang);continue;}else if(skipLang){continue;}
if(reImport.test(line)){match=reImport.exec(line);loadImport(baseURL+match[1]);}}
var tmp=line.match(reSplit);if(tmp&&tmp.length==3){dictionary[tmp[1]]=evalString(tmp[2]);}}}
function loadImport(url){loadResource(url,function(content){parseRawLines(content,false);},null,false);}
parseRawLines(text,true);return dictionary;}
function loadResource(url,onSuccess,onFailure,asynchronous){onSuccess=onSuccess||function _onSuccess(data){};onFailure=onFailure||function _onFailure(){consoleWarn(url+' not found.');};var xhr=new XMLHttpRequest();xhr.open('GET',url,asynchronous);if(xhr.overrideMimeType){xhr.overrideMimeType('text/plain; charset=utf-8');}
xhr.onreadystatechange=function(){if(xhr.readyState==4){if(xhr.status==200||xhr.status===0){onSuccess(xhr.responseText);}else{onFailure();}}};xhr.onerror=onFailure;xhr.ontimeout=onFailure;try{xhr.send(null);}catch(e){onFailure();}}
loadResource(href,function(response){var data=parseProperties(response);for(var key in data){var id,prop,index=key.lastIndexOf('.');if(index>0){id=key.substring(0,index);prop=key.substr(index+1);}else{id=key;prop=gTextProp;}
if(!gL10nData[id]){gL10nData[id]={};}
gL10nData[id][prop]=data[key];}
if(successCallback){successCallback();}},failureCallback,gAsyncResourceLoading);};function loadLocale(lang,callback){callback=callback||function _callback(){};clear();gLanguage=lang;var langLinks=getL10nResourceLinks();var langCount=langLinks.length;if(langCount==0){var dict=getL10nDictionary();if(dict&&dict.locales&&dict.default_locale){consoleLog('using the embedded JSON directory, early way out');gL10nData=dict.locales[lang]||dict.locales[dict.default_locale];callback();}else{consoleLog('no resource to load, early way out');}
fireL10nReadyEvent(lang);gReadyState='complete';return;}
var onResourceLoaded=null;var gResourceCount=0;onResourceLoaded=function(){gResourceCount++;if(gResourceCount>=langCount){callback();fireL10nReadyEvent(lang);gReadyState='complete';}};function l10nResourceLink(link){var href=link.href;var type=link.type;this.load=function(lang,callback){var applied=lang;parseResource(href,lang,callback,function(){consoleWarn(href+' not found.');applied='';});return applied;};}
for(var i=0;i<langCount;i++){var resource=new l10nResourceLink(langLinks[i]);var rv=resource.load(lang,onResourceLoaded);if(rv!=lang){consoleWarn('"'+lang+'" resource not found');gLanguage='';}}}
function clear(){gL10nData={};gLanguage='';}
function getPluralRules(lang){var locales2rules={'af':3,'ak':4,'am':4,'ar':1,'asa':3,'az':0,'be':11,'bem':3,'bez':3,'bg':3,'bh':4,'bm':0,'bn':3,'bo':0,'br':20,'brx':3,'bs':11,'ca':3,'cgg':3,'chr':3,'cs':12,'cy':17,'da':3,'de':3,'dv':3,'dz':0,'ee':3,'el':3,'en':3,'eo':3,'es':3,'et':3,'eu':3,'fa':0,'ff':5,'fi':3,'fil':4,'fo':3,'fr':5,'fur':3,'fy':3,'ga':8,'gd':24,'gl':3,'gsw':3,'gu':3,'guw':4,'gv':23,'ha':3,'haw':3,'he':2,'hi':4,'hr':11,'hu':0,'id':0,'ig':0,'ii':0,'is':3,'it':3,'iu':7,'ja':0,'jmc':3,'jv':0,'ka':0,'kab':5,'kaj':3,'kcg':3,'kde':0,'kea':0,'kk':3,'kl':3,'km':0,'kn':0,'ko':0,'ksb':3,'ksh':21,'ku':3,'kw':7,'lag':18,'lb':3,'lg':3,'ln':4,'lo':0,'lt':10,'lv':6,'mas':3,'mg':4,'mk':16,'ml':3,'mn':3,'mo':9,'mr':3,'ms':0,'mt':15,'my':0,'nah':3,'naq':7,'nb':3,'nd':3,'ne':3,'nl':3,'nn':3,'no':3,'nr':3,'nso':4,'ny':3,'nyn':3,'om':3,'or':3,'pa':3,'pap':3,'pl':13,'ps':3,'pt':3,'rm':3,'ro':9,'rof':3,'ru':11,'rwk':3,'sah':0,'saq':3,'se':7,'seh':3,'ses':0,'sg':0,'sh':11,'shi':19,'sk':12,'sl':14,'sma':7,'smi':7,'smj':7,'smn':7,'sms':7,'sn':3,'so':3,'sq':3,'sr':11,'ss':3,'ssy':3,'st':3,'sv':3,'sw':3,'syr':3,'ta':3,'te':3,'teo':3,'th':0,'ti':4,'tig':3,'tk':3,'tl':4,'tn':3,'to':0,'tr':0,'ts':3,'tzm':22,'uk':11,'ur':3,'ve':3,'vi':0,'vun':3,'wa':4,'wae':3,'wo':0,'xh':3,'xog':3,'yo':0,'zh':0,'zu':3};function isIn(n,list){return list.indexOf(n)!==-1;}
function isBetween(n,start,end){return start<=n&&n<=end;}
var pluralRules={'0':function(n){return'other';},'1':function(n){if((isBetween((n%100),3,10)))
return'few';if(n===0)
return'zero';if((isBetween((n%100),11,99)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'2':function(n){if(n!==0&&(n%10)===0)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'3':function(n){if(n==1)
return'one';return'other';},'4':function(n){if((isBetween(n,0,1)))
return'one';return'other';},'5':function(n){if((isBetween(n,0,2))&&n!=2)
return'one';return'other';},'6':function(n){if(n===0)
return'zero';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'7':function(n){if(n==2)
return'two';if(n==1)
return'one';return'other';},'8':function(n){if((isBetween(n,3,6)))
return'few';if((isBetween(n,7,10)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'9':function(n){if(n===0||n!=1&&(isBetween((n%100),1,19)))
return'few';if(n==1)
return'one';return'other';},'10':function(n){if((isBetween((n%10),2,9))&&!(isBetween((n%100),11,19)))
return'few';if((n%10)==1&&!(isBetween((n%100),11,19)))
return'one';return'other';},'11':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if((n%10)===0||(isBetween((n%10),5,9))||(isBetween((n%100),11,14)))
return'many';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'12':function(n){if((isBetween(n,2,4)))
return'few';if(n==1)
return'one';return'other';},'13':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if(n!=1&&(isBetween((n%10),0,1))||(isBetween((n%10),5,9))||(isBetween((n%100),12,14)))
return'many';if(n==1)
return'one';return'other';},'14':function(n){if((isBetween((n%100),3,4)))
return'few';if((n%100)==2)
return'two';if((n%100)==1)
return'one';return'other';},'15':function(n){if(n===0||(isBetween((n%100),2,10)))
return'few';if((isBetween((n%100),11,19)))
return'many';if(n==1)
return'one';return'other';},'16':function(n){if((n%10)==1&&n!=11)
return'one';return'other';},'17':function(n){if(n==3)
return'few';if(n===0)
return'zero';if(n==6)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'18':function(n){if(n===0)
return'zero';if((isBetween(n,0,2))&&n!==0&&n!=2)
return'one';return'other';},'19':function(n){if((isBetween(n,2,10)))
return'few';if((isBetween(n,0,1)))
return'one';return'other';},'20':function(n){if((isBetween((n%10),3,4)||((n%10)==9))&&!(isBetween((n%100),10,19)||isBetween((n%100),70,79)||isBetween((n%100),90,99)))
return'few';if((n%1000000)===0&&n!==0)
return'many';if((n%10)==2&&!isIn((n%100),[12,72,92]))
return'two';if((n%10)==1&&!isIn((n%100),[11,71,91]))
return'one';return'other';},'21':function(n){if(n===0)
return'zero';if(n==1)
return'one';return'other';},'22':function(n){if((isBetween(n,0,1))||(isBetween(n,11,99)))
return'one';return'other';},'23':function(n){if((isBetween((n%10),1,2))||(n%20)===0)
return'one';return'other';},'24':function(n){if((isBetween(n,3,10)||isBetween(n,13,19)))
return'few';if(isIn(n,[2,12]))
return'two';if(isIn(n,[1,11]))
return'one';return'other';}};var index=locales2rules[lang.replace(/-.*$/,'')];if(!(index in pluralRules)){consoleWarn('plural form unknown for ['+lang+']');return function(){return'other';};}
return pluralRules[index];}
gMacros.plural=function(str,param,key,prop){var n=parseFloat(param);if(isNaN(n))
return str;if(prop!=gTextProp)
return str;if(!gMacros._pluralRules){gMacros._pluralRules=getPluralRules(gLanguage);}
var index='['+gMacros._pluralRules(n)+']';if(n===0&&(key+'[zero]')in gL10nData){str=gL10nData[key+'[zero]'][prop];}else if(n==1&&(key+'[one]')in gL10nData){str=gL10nData[key+'[one]'][prop];}else if(n==2&&(key+'[two]')in gL10nData){str=gL10nData[key+'[two]'][prop];}else if((key+index)in gL10nData){str=gL10nData[key+index][prop];}else if((key+'[other]')in gL10nData){str=gL10nData[key+'[other]'][prop];}
return str;};function getL10nData(key,args){var data=gL10nData[key];if(!data){consoleWarn('#'+key+' is undefined.');}
var rv={};for(var prop in data){var str=data[prop];str=substIndexes(str,args,key,prop);str=substArguments(str,args,key);rv[prop]=str;}
return rv;}
function substIndexes(str,args,key,prop){var reIndex=/\{\[\s*([a-zA-Z]+)\(([a-zA-Z]+)\)\s*\]\}/;var reMatch=reIndex.exec(str);if(!reMatch||!reMatch.length)
return str;var macroName=reMatch[1];var paramName=reMatch[2];var param;if(args&&paramName in args){param=args[paramName];}else if(paramName in gL10nData){param=gL10nData[paramName];}
if(macroName in gMacros){var macro=gMacros[macroName];str=macro(str,param,key,prop);}
return str;}
function substArguments(str,args,key){var reArgs=/\{\{\s*(.+?)\s*\}\}/;var match=reArgs.exec(str);while(match){if(!match||match.length<2)
return str;var arg=match[1];var sub='';if(args&&arg in args){sub=args[arg];}else if(arg in gL10nData){sub=gL10nData[arg][gTextProp];}else{consoleLog('argument {{'+arg+'}} for #'+key+' is undefined.');return str;}
str=str.substring(0,match.index)+sub+
str.substr(match.index+match[0].length);match=reArgs.exec(str);}
return str;}
function translateElement(element){var l10n=getL10nAttributes(element);if(!l10n.id){return;}
var data=getL10nData(l10n.id,l10n.args);if(!data){consoleWarn('#'+l10n.id+' is undefined.');return;}
if(data[gTextProp]){if(element.children.length===0){element[gTextProp]=data[gTextProp];}else{var children=element.childNodes;var found=false;for(var i=0,l=children.length;i<l;i++){if(children[i].nodeType===3&&/\S/.test(children[i].nodeValue)){if(found){children[i].nodeValue='';}else{children[i].nodeValue=data[gTextProp];found=true;}}}
if(!found){var textNode=document.createTextNode(data[gTextProp]);element.insertBefore(textNode,element.firstChild);}}
delete data[gTextProp];}
for(var k in data){element[k]=data[k];}}
function translateFragment(element){element=element||document.documentElement;var children=getTranslatableChildren(element);var elementCount=children.length;for(var i=0;i<elementCount;i++){translateElement(children[i]);}
translateElement(element);}
function l10nStartup(){gReadyState='interactive';consoleLog('loading ['+navigator.language+'] resources, '+
(gAsyncResourceLoading?'asynchronously.':'synchronously.'));if(document.documentElement.lang===navigator.language){loadLocale(navigator.language);}else{loadLocale(navigator.language,translateFragment);}}
if(typeof(document)!=='undefined'){if(document.readyState==='complete'||document.readyState==='interactive'){window.setTimeout(l10nStartup);}else{document.addEventListener('DOMContentLoaded',l10nStartup);}}
if('mozSettings'in navigator&&navigator.mozSettings){navigator.mozSettings.addObserver('language.current',function(event){loadLocale(event.settingValue,translateFragment);});}
navigator.mozL10n={get:function l10n_get(key,args,fallback){var data=getL10nData(key,args)||fallback;if(data){return'textContent'in data?data.textContent:'';}
return'{{'+key+'}}';},get language(){return{get code(){return gLanguage;},set code(lang){loadLocale(lang,translateFragment);},get direction(){var rtlList=['ar','he','fa','ps','ur'];return(rtlList.indexOf(gLanguage)>=0)?'rtl':'ltr';}};},translate:translateFragment,get dictionary(){return JSON.parse(JSON.stringify(gL10nData));},get readyState(){return gReadyState;},ready:function l10n_ready(callback){if(!callback){return;}else if(gReadyState=='complete'||gReadyState=='interactive'){window.setTimeout(callback);}else{window.addEventListener('localized',callback);}}};consoleLog('library loaded.');})(this);;'use strict';navigator.mozL10n.DateTimeFormat=function(locales,options){var _=navigator.mozL10n.get;function localeFormat(d,format){var tokens=format.match(/(%E.|%O.|%.)/g);for(var i=0;tokens&&i<tokens.length;i++){var value='';switch(tokens[i]){case'%a':value=_('weekday-'+d.getDay()+'-short');break;case'%A':value=_('weekday-'+d.getDay()+'-long');break;case'%b':case'%h':value=_('month-'+d.getMonth()+'-short');break;case'%B':value=_('month-'+d.getMonth()+'-long');break;case'%Eb':value=_('month-'+d.getMonth()+'-genitive');break;case'%I':value=d.getHours()%12||12;break;case'%e':value=d.getDate();break;case'%c':case'%x':case'%X':var tmp=_('dateTimeFormat_'+tokens[i]);if(tmp&&!(/(%c|%x|%X)/).test(tmp)){value=localeFormat(d,tmp);}
break;}
format=format.replace(tokens[i],value||d.toLocaleFormat(tokens[i]));}
return format;}
function prettyDate(time,useCompactFormat){switch(time.constructor){case String:time=parseInt(time);break;case Date:time=time.getTime();break;}
var secDiff=(Date.now()-time)/1000;if(isNaN(secDiff)){return _('incorrectDate');}
var f=useCompactFormat?'-short':'-long';if(secDiff>=0){var dayDiff=Math.floor(secDiff/86400);if(secDiff<3600){return _('minutesAgo'+f,{m:Math.floor(secDiff/60)});}else if(dayDiff===0){return _('hoursAgo'+f,{h:Math.floor(secDiff/3600)});}else if(dayDiff<10){return _('daysAgo'+f,{d:dayDiff});}}
if(secDiff<0){secDiff=-secDiff;dayDiff=Math.floor(secDiff/86400);if(secDiff<3600){return _('inMinutes'+f,{m:Math.floor(secDiff/60)});}else if(dayDiff===0){return _('inHours'+f,{h:Math.floor(secDiff/3600)});}else if(dayDiff<10){return _('inDays'+f,{d:dayDiff});}}
return localeFormat(new Date(time),'%x');}
return{localeDateString:function localeDateString(d){return localeFormat(d,'%x');},localeTimeString:function localeTimeString(d){return localeFormat(d,'%X');},localeString:function localeString(d){return localeFormat(d,'%c');},localeFormat:localeFormat,fromNow:prettyDate};};;'use strict';var Settings={get mozSettings(){var settings=window.navigator.mozSettings;return(settings&&typeof(settings.createLock)=='function')?settings:null;},preInit:function settings_preInit(){var settings=this.mozSettings;if(!settings)
return;this.getSettings(null);settings.onsettingchange=(function settingChanged(event){var key=event.settingName;var value=event.settingValue;if(this._settingsCache){this._settingsCache[key]=value;}
if(!this._initialized){return;}
var rule='[data-name="'+key+'"]:not([data-ignore])';var spanField=document.querySelector(rule);if(spanField){rule='[data-setting="'+key+'"] [value="'+value+'"]';var option=document.querySelector(rule);if(option){spanField.dataset.l10nId=option.dataset.l10nId;spanField.textContent=option.textContent;}else{spanField.textContent=value;}}
var input=document.querySelector('input[name="'+key+'"]');if(!input)
return;switch(input.dataset.type||input.type){case'checkbox':case'switch':if(input.checked==value)
return;input.checked=value;break;case'range':if(input.value==value)
return;input.value=value;input.refresh();break;case'select':for(var i=0;i<input.options.length;i++){if(input.options[i].value==value){input.options[i].selected=true;break;}}
break;}}).bind(this);},_initialized:false,init:function settings_init(){this._initialized=true;if(!this.mozSettings||!navigator.mozSetMessageHandler){return;}
navigator.mozSetMessageHandler('activity',this.webActivityHandler);this.presetPanel();},loadPanel:function settings_loadPanel(panel){if(!panel)
return;for(var i=0;i<panel.childNodes.length;i++){if(panel.childNodes[i].nodeType==document.COMMENT_NODE){panel.innerHTML=panel.childNodes[i].nodeValue;break;}}
navigator.mozL10n.translate(panel);var scripts=panel.querySelectorAll('script');for(var i=0;i<scripts.length;i++){var src=scripts[i].getAttribute('src')
if(document.head.querySelector('script[src="'+src+'"]')){continue;}
var script=document.createElement('script');script.type='application/javascript';script.src=src;document.head.appendChild(script);}
var stylesheets=panel.querySelectorAll('link');for(var i=0;i<stylesheets.length;i++){var href=stylesheets[i].getAttribute('href');if(document.head.querySelector('link[href="'+href+'"]'))
continue;var stylesheet=document.createElement('link');stylesheet.type='text/css';stylesheet.rel='stylesheet';stylesheet.href=href;document.head.appendChild(stylesheet);}
var self=this;var rule='a[href^="http"], a[href^="tel"], [data-href]';var links=panel.querySelectorAll(rule);for(i=0;i<links.length;i++){var link=links[i];if(!link.dataset.href){link.dataset.href=link.href;link.href='#';}
if(!link.dataset.href.startsWith('#')){link.onclick=function(){openLink(this.dataset.href);return false;};}else if(!link.dataset.href.endsWith('Settings')){link.onclick=function(){openDialog(this.dataset.href.substr(1));return false;};}else{link.onclick=function(){self.openDialog(this.dataset.href.substr(1));return false;};}}},_settingsCache:null,get settingsCache(){return this._settingsCache;},_settingsCacheRequestSent:false,_pendingSettingsCallbacks:[],getSettings:function(callback){var settings=this.mozSettings;if(!settings)
return;if(this._settingsCache&&callback){callback(this._settingsCache);return;}
if(!this._settingsCacheRequestSent&&!this._settingsCache){this._settingsCacheRequestSent=true;var lock=settings.createLock();var request=lock.get('*');request.onsuccess=function(e){var result=request.result;var cachedResult={};for(var attr in result){cachedResult[attr]=result[attr];}
Settings._settingsCache=cachedResult;var cbk;while((cbk=Settings._pendingSettingsCallbacks.pop())){cbk(result);}};}
if(callback){this._pendingSettingsCallbacks.push(callback);}},presetPanel:function settings_presetPanel(panel){this.getSettings(function(result){panel=panel||document;var rule='input[type="checkbox"]:not([data-ignore])';var checkboxes=panel.querySelectorAll(rule);for(var i=0;i<checkboxes.length;i++){var key=checkboxes[i].name;if(key&&result[key]!=undefined){checkboxes[i].checked=!!result[key];}}
setTimeout(function(){for(var i=0;i<checkboxes.length;i++){if(checkboxes[i].classList.contains('initial')){checkboxes[i].classList.remove('initial');}}},0);rule='input[type="radio"]:not([data-ignore])';var radios=panel.querySelectorAll(rule);for(i=0;i<radios.length;i++){var key=radios[i].name;if(key&&result[key]!=undefined){radios[i].checked=(result[key]===radios[i].value);}}
rule='input[type="text"]:not([data-ignore])';var texts=panel.querySelectorAll(rule);for(i=0;i<texts.length;i++){var key=texts[i].name;if(key&&result[key]!=undefined){texts[i].value=result[key];}}
rule='input[type="range"]:not([data-ignore])';var ranges=panel.querySelectorAll(rule);for(i=0;i<ranges.length;i++){var key=ranges[i].name;if(key&&result[key]!=undefined){ranges[i].value=parseFloat(result[key]);ranges[i].refresh();}}
var fakeSelector=function(select){var parent=select.parentElement;var button=select.previousElementSibling;var index=select.selectedIndex;if(index>=0){var selection=select.options[index];button.textContent=selection.textContent;button.dataset.l10nId=selection.dataset.l10nId;}
if(parent.classList.contains('fake-select')){select.addEventListener('change',function(){var newSelection=this.options[this.selectedIndex];button.textContent=newSelection.textContent;button.dataset.l10nId=newSelection.dataset.l10nId;});}};var selects=panel.querySelectorAll('select');for(var i=0,count=selects.length;i<count;i++){var select=selects[i];var key=select.name;if(key&&result[key]!=undefined){var value=result[key];var option='option[value="'+value+'"]';var selectOption=select.querySelector(option);if(selectOption){selectOption.selected=true;}}
fakeSelector(select);}
rule='[data-name]:not([data-ignore])';var spanFields=panel.querySelectorAll(rule);for(i=0;i<spanFields.length;i++){var key=spanFields[i].dataset.name;if(key&&result[key]!=undefined){rule='[data-setting="'+key+'"] '+'[value="'+result[key]+'"]';var option=document.querySelector(rule);if(option){spanFields[i].dataset.l10nId=option.dataset.l10nId;spanFields[i].textContent=option.textContent;}else{spanFields[i].textContent=result[key];}}else{switch(key){case'deviceinfo.software':var _=navigator.mozL10n.get;var text=_('brandShortName')+' '+
result['deviceinfo.os'];spanFields[i].textContent=text;break;case'deviceinfo.firmware_revision':spanFields[i].parentNode.hidden=true;break;}}}});},webActivityHandler:function settings_handleActivity(activityRequest){var name=activityRequest.source.name;switch(name){case'configure':var section=activityRequest.source.data.section||'root';var sectionElement=document.getElementById(section);if(!sectionElement||sectionElement.tagName!=='SECTION'){var msg='Trying to open an unexistent section: '+section;console.warn(msg);activityRequest.postError(msg);return;}
setTimeout(function settings_goToSection(){document.location.hash=section;});break;}},handleEvent:function settings_handleEvent(event){var input=event.target;var type=input.dataset.type||input.type;var key=input.name;var settings=window.navigator.mozSettings;if(!key||!settings||event.type!='change')
return;if(input.dataset.setting)
return;var value;switch(type){case'checkbox':case'switch':value=input.checked;break;case'range':value=parseFloat(input.value).toFixed(1);break;case'select-one':case'radio':case'text':case'password':value=input.value;if(input.dataset.valueType==='integer')
value=parseInt(value);break;}
var cset={};cset[key]=value;settings.createLock().set(cset);},openDialog:function settings_openDialog(dialogID){var settings=this.mozSettings;var dialog=document.getElementById(dialogID);var fields=dialog.querySelectorAll('[data-setting]:not([data-ignore])');function reset(){if(settings){var lock=settings.createLock();for(var i=0;i<fields.length;i++){(function(input){var key=input.dataset.setting;var request=lock.get(key);request.onsuccess=function(){switch(input.type){case'radio':input.checked=(input.value==request.result[key]);break;case'checkbox':input.checked=request.result[key]||false;break;default:input.value=request.result[key]||'';break;}};})(fields[i]);}}}
function submit(){if(settings){fields=dialog.querySelectorAll('[data-setting]:not([data-ignore])');var lock=settings.createLock();for(var i=0;i<fields.length;i++){var input=fields[i];var cset={};var key=input.dataset.setting;switch(input.type){case'radio':if(input.checked)
cset[key]=input.value;break;case'checkbox':cset[key]=input.checked;break;default:cset[key]=input.value;break;}
lock.set(cset);}}}
reset();openDialog(dialogID,submit);},getSupportedLanguages:function settings_getLanguages(callback){var LANGUAGES='shared/resources/languages.json';if(this._languages){callback(this._languages);}else{var self=this;var xhr=new XMLHttpRequest();xhr.onreadystatechange=function loadSupportedLocales(){if(xhr.readyState===4){if(xhr.status===0||xhr.status===200){self._languages=xhr.response;callback(self._languages);}else{console.error('Failed to fetch languages.json: ',xhr.statusText);}}};xhr.open('GET',LANGUAGES,true);xhr.responseType='json';xhr.send();}},updateLanguagePanel:function settings_updateLanguagePanel(){var panel=document.getElementById('languages');if(panel){var d=new Date();var f=new navigator.mozL10n.DateTimeFormat();var _=navigator.mozL10n.get;panel.querySelector('#region-date').textContent=f.localeFormat(d,_('longDateFormat'));panel.querySelector('#region-time').textContent=f.localeFormat(d,_('shortTimeFormat'));}}};window.addEventListener('load',function loadSettings(){window.removeEventListener('load',loadSettings);window.addEventListener('change',Settings);Settings.init();handleRadioAndCardState();setTimeout(function(){var scripts=['js/utils.js','shared/js/mouse_event_shim.js','js/airplane_mode.js','js/battery.js','js/app_storage.js','js/media_storage.js','shared/js/mobile_operator.js','js/connectivity.js','js/security_privacy.js','js/icc_menu.js'];scripts.forEach(function attachScripts(src){var script=document.createElement('script');script.src=src;document.head.appendChild(script);});});function lazyLoad(panel){if(panel.children.length)
return;var selector='section[id^="'+panel.id+'-"]';var subPanels=document.querySelectorAll(selector);for(var i=0;i<subPanels.length;i++){Settings.loadPanel(subPanels[i]);}
Settings.loadPanel(panel);switch(panel.id){case'display':bug344618_polyfill();var manualBrightness=panel.querySelector('#brightness-manual');var autoBrightnessSetting='screen.automatic-brightness';var settings=Settings.mozSettings;if(!settings)
return;settings.addObserver(autoBrightnessSetting,function(event){manualBrightness.hidden=event.settingValue;});var req=settings.createLock().get(autoBrightnessSetting);req.onsuccess=function brightness_onsuccess(){manualBrightness.hidden=req.result[autoBrightnessSetting];};break;case'sound':bug344618_polyfill();break;case'languages':var langSel=document.querySelector('select[name="language.current"]');langSel.innerHTML='';Settings.getSupportedLanguages(function fillLanguageList(languages){for(var lang in languages){var option=document.createElement('option');option.value=lang;option.textContent=languages[lang];option.selected=(lang==document.documentElement.lang);langSel.appendChild(option);}});Settings.updateLanguagePanel();break;case'mediaStorage':MediaStorage.initUI();break;case'deviceStorage':AppStorage.update();break;case'battery':Battery.update();break;}
for(var i=0;i<subPanels.length;i++){Settings.presetPanel(subPanels[i]);}
Settings.presetPanel(panel);}
var oldHash=window.location.hash||'#root';function showPanel(){var hash=window.location.hash;var oldPanel=document.querySelector(oldHash);var newPanel=document.querySelector(hash);lazyLoad(newPanel);oldPanel.className=newPanel.className?'peek':'peek previous forward';newPanel.className=newPanel.className?'current peek':'peek current forward';oldHash=hash;if((window.scrollX!==0)||(window.scrollY!==0)){window.scrollTo(0,0);}
window.addEventListener('transitionend',function paintWait(){window.removeEventListener('transitionend',paintWait);setTimeout(function nextTick(){oldPanel.classList.remove('peek');oldPanel.classList.remove('forward');newPanel.classList.remove('peek');newPanel.classList.remove('forward');if(oldPanel.className==='current')
return;oldPanel.addEventListener('transitionend',function onTransitionEnd(){oldPanel.removeEventListener('transitionend',onTransitionEnd);if(newPanel.id=='about-licensing'){var iframe=document.getElementById('os-license');iframe.src=iframe.dataset.src;}});});});}
function handleRadioAndCardState(){function updateDataSubpanelItem(disabled){var item=document.getElementById('data-connectivity');var link=document.getElementById('menuItem-cellularAndData');if(!item||!link)
return;if(disabled){item.classList.add('carrier-disabled');link.onclick=function(){return false;}}else{item.classList.remove('carrier-disabled');link.onclick=null;}}
function updateCallSubpanelItem(disabled){var item=document.getElementById('call-settings');var link=document.getElementById('menuItem-callSettings');if(!item||!link)
return;if(disabled){item.classList.add('call-settings-disabled');link.onclick=function(){return false;};}else{item.classList.remove('call-settings-disabled');link.onclick=null;}}
var key='ril.radio.disabled';var settings=Settings.mozSettings;if(!settings)
return;var req=settings.createLock().get(key);req.onsuccess=function(){var value=req.result[key];updateDataSubpanelItem(value);updateCallSubpanelItem(value);};settings.addObserver(key,function(evt){updateDataSubpanelItem(evt.settingValue);updateCallSubpanelItem(evt.settingValue);});}
window.addEventListener('hashchange',showPanel);switch(window.location.hash){case'#root':break;case'':document.location.hash='root';break;default:document.getElementById('root').className='previous';showPanel();break;}});window.addEventListener('keydown',function handleSpecialKeys(event){if(document.location.hash!='#root'&&event.keyCode===event.DOM_VK_ESCAPE){event.preventDefault();event.stopPropagation();var dialog=document.querySelector('#dialogs .active');if(dialog){dialog.classList.remove('active');document.body.classList.remove('dialog');}else{document.location.hash='#root';}}else if(event.keyCode===event.DOM_VK_RETURN){event.target.blur();event.stopPropagation();event.preventDefault();}});window.addEventListener('localized',function showLanguages(){document.documentElement.lang=navigator.mozL10n.language.code;document.documentElement.dir=navigator.mozL10n.language.direction;Settings.getSupportedLanguages(function displayLang(languages){document.getElementById('language-desc').textContent=languages[navigator.mozL10n.language.code];});Settings.updateLanguagePanel();});Settings.preInit();MouseEventShim.trackMouseMoves=false;